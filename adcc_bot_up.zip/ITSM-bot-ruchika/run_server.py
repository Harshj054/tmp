import asyncio
import websockets
import argparse
from app.core.config import settings
from app.core.logger import setup_logging, logger
from app.services.api_client import itsm_client
from app.services.llm_service import check_ollama_reachable
from app.bot.ws_handler import ws_handler

async def main():
    setup_logging()
    
    parser = argparse.ArgumentParser(description="ITSM Bot Server")
    parser.add_argument("--host", default=settings.HOST)
    parser.add_argument("--port", type=int, default=settings.PORT)
    args = parser.parse_args()

    logger.info(f"Starting ITSM Bot Server on {args.host}:{args.port}")
    logger.info(f"Backend: {settings.BACKEND_BASE}")
    logger.info(f"Ollama: {settings.OLLAMA_BASE_URL} ({settings.OLLAMA_MODEL})")

    # Ollama reachability check
    await check_ollama_reachable()

    # Initial login to ITSM Backend
    logger.info("Connecting to ITSM Backend...")
    if await itsm_client.login():
        logger.info("[OK] Logged in successfully.")
    else:
        logger.warning("[FAIL] Initial login failed - will retry at runtime.")

    async with websockets.serve(ws_handler, args.host, args.port):
        logger.info(f"WebSocket server listening on ws://{args.host}:{args.port}")
        await asyncio.Future() # Run forever

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Server stopped by user.")
