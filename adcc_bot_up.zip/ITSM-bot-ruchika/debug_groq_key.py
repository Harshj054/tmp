import os
from groq import Groq

key = "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"
client = Groq(api_key=key)

try:
    models = client.models.list()
    print("SUCCESS: Key is valid.")
    print("Available models (first 3):", [m.id for m in models.data[:3]])
except Exception as e:
    print(f"FAILED: {e}")
