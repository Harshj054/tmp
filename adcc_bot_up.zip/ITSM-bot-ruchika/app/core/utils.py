import re
from datetime import datetime
from typing import Optional
from dateutil import parser as dateutil_parser

_BRAND_PATTERNS = [
    (re.compile(r"\biTop\b",  re.IGNORECASE), "the ITSM system"),
    (re.compile(r"\bGLPi?\b", re.IGNORECASE), "the ITSM system"),
]

def scrub_brands(text: str) -> str:
    if not text:
        return text
    for pattern, replacement in _BRAND_PATTERNS:
        text = pattern.sub(replacement, text)
    return text

_DATE_CLEANUPS = [
    (re.compile(r"^(\d{2})[.\-/](\d{2})[.\-/](\d{4})(.*)$"),
     lambda m: f"{m.group(3)}-{m.group(2)}-{m.group(1)}{m.group(4)}"),
    (re.compile(r"^(\d{4})/(\d{2})/(\d{2})(.*)$"),
     lambda m: f"{m.group(1)}-{m.group(2)}-{m.group(3)}{m.group(4)}"),
]

def normalize_date(raw: str) -> Optional[str]:
    if not raw or not raw.strip():
        return raw
    value = raw.strip()
    for pattern, replacer in _DATE_CLEANUPS:
        m = pattern.match(value)
        if m:
            value = replacer(m)
            break
    try:
        dt = dateutil_parser.parse(value)
        return dt.strftime("%Y-%m-%dT%H:%M")
    except:
        return None
