from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import Optional

class Settings(BaseSettings):
    # OLLAMA CONFIG
    OLLAMA_BASE_URL: str = "http://localhost:11434"
    OLLAMA_MODEL: str = "qwen3.5:4b"

    # ITSM BACKEND CONFIG
    BACKEND_BASE: str = "http://localhost:4000"
    ITSM_USERNAME: str = "admin@admin.com"
    ITSM_PASSWORD: str = "password123"
    ITSM_CLIENT_ID: str = "string"
    ITSM_CLIENT_SECRET: str = "********"

    # GROQ CONFIG
    GROQ_API_KEY: Optional[str] = None

    # APP CONFIG
    HOST: str = "0.0.0.0"
    PORT: int = 8765
    DEBUG: bool = False
    
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
