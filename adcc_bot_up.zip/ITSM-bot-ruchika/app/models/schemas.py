from pydantic import BaseModel, Field, EmailStr
from typing import Optional, List, Union, Dict, Any
from datetime import datetime

class TicketCreate(BaseModel):
    title: str
    description: str
    priority: str = "3"
    service_name: str = ""
    request_type: str = "incident"
    servicesubcategory_name: str = ""
    org_name: str = ""

class ProblemCreate(BaseModel):
    title: str
    description: str
    impact: str = "3"
    urgency: str = "3"
    org_name: str = ""
    service_name: str = ""

class KnownErrorCreate(BaseModel):
    name: str
    symptom: str
    workaround: str = ""
    root_cause: str = ""
    solution: str = ""
    error_code: str = ""
    domain: str = "Application"
    org_name: str = ""

class ChangeCreate(BaseModel):
    title: str
    description: str
    fallback_plan: str
    category: str = "normal"
    outage: bool = False
    start_date: str
    end_date: str

class ServiceCreate(BaseModel):
    name: str
    org_name: str
    description: str
    status: str = "active"

class SLTCreate(BaseModel):
    name: str
    priority: str = "3"
    metric: str
    value: int
    unit: str = "minutes"
    request_type: str = "incident"

class SLACreate(BaseModel):
    name: str
    org_name: str
    description: str
    slt_ids: List[str] = []

class ContractCreate(BaseModel):
    name: str
    org_name: str
    provider_org_name: str
    service_id: str
    sla_id: str
    start_date: str
    end_date: str
    cost: float = 0.0
    cost_currency: str = "USD"
    description: str

class StatsQuery(BaseModel):
    entity: Optional[str] = "all"
    status: Optional[str] = "all"

class LLMResponse(BaseModel):
    intent: str = "fallback"
    entity: str = ""
    params: Dict[str, Any] = {}
    filters: Dict[str, Any] = {}

class SessionMessage(BaseModel):
    role: str
    text: str
    ts: str = Field(default_factory=lambda: datetime.now().isoformat())
