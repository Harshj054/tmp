import json
import asyncio
import websockets
from websockets.legacy.server import WebSocketServerProtocol
from app.core.logger import logger
from app.bot.session import ConnCtx
from app.services.llm_service import call_llm, stream_llm_reply
from app.bot.dispatcher import dispatch, build_final_reply, send_status, send_reply, send_error

async def process_message(ctx: ConnCtx, message: str, session_id: str = ""):
    session = ctx.resolve_session(session_id)
    if session:
        session.add_history("user", message)

    await send_status(ctx, "Processing your request...", session_id=session_id)

    history = [msg.model_dump() for msg in session.history] if session else []
    llm_res = await call_llm(message, history=history)
    
    intent = llm_res.intent
    entity = llm_res.entity
    params = llm_res.params
    filters = llm_res.filters

    # Context Memory
    if session:
        if not entity and session.last_entity:
            entity = session.last_entity
        if entity:
            session.last_entity = entity

    if intent == "fallback":
        # Check if we already have a reply from pre-classification or similar
        pre_reply = params.get("reply")
        if pre_reply:
            await send_reply(ctx, pre_reply, session_id=session_id)
            if session: session.add_history("bot", pre_reply)
            return

        # Stream the fallback/general reply for better UX
        full_reply = ""
        async for chunk in stream_llm_reply(message, history=history):
            full_reply += chunk
            await ctx.ws.send(json.dumps({
                "type": "reply_chunk", 
                "text": chunk, 
                "session_id": session_id
            }))
        
        # Send a final 'reply' type message to signal completion if needed by UI
        await send_reply(ctx, "", session_id=session_id)
        if session: session.add_history("bot", full_reply)
        return

    try:
        status, data, params = await dispatch(ctx, intent, entity, params, filters, session_id=session_id)
        final_reply = build_final_reply(intent, status, data, entity=entity)
        await send_reply(ctx, final_reply, session_id=session_id)
        if session: session.add_history("bot", final_reply)
    except Exception as e:
        logger.error(f"Processing error: {e}")
        await send_error(ctx, f"An error occurred: {e}", session_id=session_id)

async def handle_session_command(ctx: ConnCtx, msg: dict):
    mtype = msg.get("type","")
    session_id = msg.get("session_id", "")

    if mtype == "session_create":
        name = msg.get("name", "New Session")
        session = ctx.create_session(name)
        ctx.set_active(session.session_id)
        await ctx.ws.send(json.dumps({
            "type": "session_created", 
            "session_id": session.session_id, 
            "name": session.name
        }))
        return True

    if mtype == "session_switch":
        if ctx.set_active(session_id):
            await ctx.ws.send(json.dumps({
                "type": "session_switched", 
                "session_id": session_id
            }))
        else:
            await send_error(ctx, f"Session {session_id} not found")
        return True

    if mtype == "session_list":
        sessions = [s.to_dict() for s in ctx.list_sessions()]
        await ctx.ws.send(json.dumps({
            "type": "session_list", 
            "sessions": sessions,
            "active_session_id": ctx.active_session().session_id if ctx.active_session() else ""
        }))
        return True

    if mtype == "session_delete":
        if ctx.delete_session(session_id):
            await ctx.ws.send(json.dumps({
                "type": "session_deleted", 
                "session_id": session_id
            }))
        else:
            await send_error(ctx, f"Session {session_id} not found")
        return True

    return False

async def ws_handler(ws: WebSocketServerProtocol):
    addr = str(ws.remote_address)
    logger.info(f"New connection from {addr}")

    # Immediate signal to UI that connection is established
    try:
        await ws.send(json.dumps({"type": "status", "text": "Connected to Bot Server"}))
    except Exception as e:
        logger.warning(f"Failed to send initial status: {e}")

    try:
        # Auth handshake
        raw = await asyncio.wait_for(ws.recv(), timeout=30.0)
        msg = json.loads(raw)
        if msg.get("type") != "auth" or not msg.get("token"):
            await ws.send(json.dumps({"type": "error", "text": "Auth required"}))
            return
        
        ctx = ConnCtx(ws, msg["token"])
        await ws.send(json.dumps({"type": "status", "text": "Authenticated"}))
        logger.info(f"Authenticated {addr}")

        async for raw_msg in ws:
            msg = json.loads(raw_msg)
            mtype = msg.get("type")
            sid = msg.get("session_id", "")
            
            if mtype.startswith("session_"):
                await handle_session_command(ctx, msg)
                continue

            if mtype == "message":
                text = msg.get("text", "").strip()
                session = ctx.resolve_session(sid)
                if not session:
                    session = ctx.create_session("Default")
                    ctx.set_active(session.session_id)
                
                if session.is_busy():
                    await session.input_queue.put({"type": "input", "value": text})
                else:
                    session.active_task = asyncio.create_task(
                        process_message(ctx, text, session_id=session.session_id)
                    )
            
            elif mtype == "input":
                session = ctx.resolve_session(sid)
                if session and session.is_busy():
                    await session.input_queue.put(msg)
    
    except websockets.exceptions.ConnectionClosed:
        logger.info(f"Connection closed {addr}")
    except Exception as e:
        logger.error(f"WS Handler error: {e}")
