import uuid
import asyncio
from datetime import datetime
from typing import Dict, List, Optional
from websockets.legacy.server import WebSocketServerProtocol
from app.models.schemas import SessionMessage

class Session:
    def __init__(self, name: str):
        self.session_id: str = str(uuid.uuid4())
        self.name: str = name.strip() or "Session"
        self.created_at: datetime = datetime.now()
        self.input_queue: asyncio.Queue = asyncio.Queue()
        self.active_task: Optional[asyncio.Task] = None
        self.history: List[SessionMessage] = []
        self.last_entity: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "session_id": self.session_id,
            "name": self.name,
            "created_at": self.created_at.isoformat(),
            "msg_count": len(self.history),
            "last_entity": self.last_entity,
        }

    def add_history(self, role: str, text: str):
        self.history.append(SessionMessage(role=role, text=text))

    def is_busy(self) -> bool:
        return self.active_task is not None and not self.active_task.done()

    def cancel_task(self):
        if self.active_task and not self.active_task.done():
            self.active_task.cancel()

class ConnCtx:
    def __init__(self, ws: WebSocketServerProtocol, token: str):
        self.ws = ws
        self.token = token
        self.addr = str(ws.remote_address)
        self._sessions: Dict[str, Session] = {}
        self._active_session: Optional[Session] = None
        self._legacy_queue: asyncio.Queue = asyncio.Queue()

    def create_session(self, name: str = "Default") -> Session:
        s = Session(name)
        self._sessions[s.session_id] = s
        return s

    def get_session(self, session_id: str) -> Optional[Session]:
        return self._sessions.get(session_id)

    def delete_session(self, session_id: str) -> bool:
        s = self._sessions.pop(session_id, None)
        if s:
            s.cancel_task()
            if self._active_session and self._active_session.session_id == session_id:
                remaining = sorted(self._sessions.values(), key=lambda x: x.created_at, reverse=True)
                self._active_session = remaining[0] if remaining else None
            return True
        return False

    def set_active(self, session_id: str) -> Optional[Session]:
        s = self._sessions.get(session_id)
        if s:
            self._active_session = s
        return s

    def active_session(self) -> Optional[Session]:
        return self._active_session

    def list_sessions(self) -> List[Session]:
        return sorted(self._sessions.values(), key=lambda s: s.created_at)

    def resolve_session(self, session_id: str = "") -> Optional[Session]:
        if session_id:
            return self._sessions.get(session_id)
        return self._active_session

    @property
    def input_queue(self) -> asyncio.Queue:
        s = self._active_session
        return s.input_queue if s else self._legacy_queue
