import asyncio
import json
import httpx
from datetime import datetime
from typing import Dict, Any, List, Optional, Tuple
from app.core.logger import logger
from app.services.api_client import itsm_client
from app.bot.session import ConnCtx
from app.models.schemas import (
    TicketCreate, ProblemCreate, KnownErrorCreate, ChangeCreate, ServiceCreate, 
    SLACreate, SLTCreate, ContractCreate, StatsQuery
)

from app.core.utils import normalize_date, scrub_brands

# ---------------------------------------------
# FIELD METADATA & SCHEMAS
# ---------------------------------------------

INTENT_SCHEMAS = {
    "create_ticket": {
        "label": "Helpdesk Ticket",
        "model": TicketCreate,
        "required": ["title", "description", "priority"],
        "optional": ["service_name", "request_type", "servicesubcategory_name", "org_name"],
    },
    "create_problem": {
        "label": "Problem Management",
        "model": ProblemCreate,
        "required": ["title", "description", "impact", "urgency"],
        "optional": ["org_name", "service_name"],
    },
    "create_known_error": {
        "label": "Known Error",
        "model": KnownErrorCreate,
        "required": ["name", "symptom"],
        "optional": ["workaround", "root_cause", "solution", "error_code", "domain", "org_name"],
    },
    "create_change": {
        "label": "Change Management",
        "model": ChangeCreate,
        "required": ["title", "description", "fallback_plan", "category", "start_date", "end_date"],
        "optional": ["outage"],
    },
    "create_service": {
        "label": "Service",
        "model": ServiceCreate,
        "required": ["name", "org_name", "description"],
        "optional": ["status"],
    },
    "create_sla": {
        "label": "SLA",
        "model": SLACreate,
        "required": ["name", "description"],
        "optional": ["org_name", "slt_ids"],
    },
    "create_slt": {
        "label": "SLT",
        "model": SLTCreate,
        "required": ["name", "priority", "metric", "value", "unit", "request_type"],
        "optional": [],
    },
    "create_contract": {
        "label": "Contract",
        "model": ContractCreate,
        "required": ["name", "org_name", "provider_org_name", "service_id", "sla_id", "start_date", "end_date", "cost", "description"],
        "optional": [],
    },
}

# ---------------------------------------------
# NUMBERED OPTION LISTS
# ---------------------------------------------

PRIORITY_OPTIONS = [
    ("Critical", "1"),
    ("High",     "2"),
    ("Medium",   "3"),
    ("Low",      "4"),
]

DOMAIN_OPTIONS = [
    ("Application", "Application"),
    ("Desktop",     "Desktop"),
    ("Network",     "Network"),
    ("Server",      "Server"),
]

CATEGORY_OPTIONS = [
    ("Normal",    "normal"),
    ("Standard",  "standard"),
    ("Emergency", "emergency"),
]

OUTAGE_OPTIONS = [
    ("No",  "no"),
    ("Yes", "yes"),
]

URGENCY_OPTIONS = [
    ("Critical", "1"),
    ("High",     "2"),
    ("Medium",   "3"),
    ("Low",      "4"),
]

IMPACT_OPTIONS = [
    ("A department", "1"),
    ("A service",    "2"),
    ("A person",     "3"),
]

SERVICE_STATUS_OPTIONS = [
    ("Active",   "active"),
    ("Inactive", "inactive"),
    ("Draft",    "draft"),
]

SLT_PRIORITY_OPTIONS = [
    ("Critical", "1"),
    ("High",     "2"),
    ("Medium",   "3"),
    ("Low",      "4"),
]

SLT_UNIT_OPTIONS = [
    ("Minutes", "minutes"),
    ("Hours",   "hours"),
    ("Days",    "days"),
]

SLT_REQUEST_TYPE_OPTIONS = [
    ("Incident",        "incident"),
    ("Service Request", "service_request"),
]

SLT_METRIC_OPTIONS = [
    ("Time to own",     "Time to own"),
    ("Time to resolve", "Time to resolve"),
]

# ---------------------------------------------
# FIELD METADATA & LABELS
# ---------------------------------------------

FIELD_META = {
    "title"                  : {"hint": "Short title"},
    "description"            : {"hint": "Detailed description"},
    "service_name"           : {"hint": "Affected service name"},
    "priority"               : {"hint": "1=Critical  2=High  3=Medium  4=Low",
                                 "allowed": ["1","2","3","4"]},
    "request_type"           : {"hint": "incident  or  service_request",
                                 "allowed": ["incident","service_request"]},
    "servicesubcategory_name": {"hint": "Service sub-category name"},
    "org_name"               : {"hint": "Organisation name (exact)"},
    "impact"                 : {"hint": "1=A department  2=A service  3=A person",
                                 "allowed": ["1","2","3"]},
    "urgency"                : {"hint": "1=Critical  2=High  3=Medium  4=Low",
                                 "allowed": ["1","2","3","4"]},
    "name"                   : {"hint": "Name / title"},
    "symptom"                : {"hint": "Observable symptom"},
    "workaround"             : {"hint": "Temporary workaround"},
    "root_cause"             : {"hint": "Root cause analysis"},
    "solution"               : {"hint": "Permanent solution"},
    "error_code"             : {"hint": "Error code"},
    "domain"                 : {"hint": "1=Application  2=Desktop  3=Network  4=Server",
                                 "allowed": ["1","2","3","4", "Application", "Desktop", "Network", "Server"]},
    "category"               : {"hint": "1=Normal  2=Standard  3=Emergency",
                                 "allowed": ["1","2","3",
                                             "normal","standard","emergency",
                                             "Normal","Standard","Emergency"]},
    "outage"                 : {"hint": "1=No  2=Yes",
                                 "allowed": ["1","2","yes","no","Yes","No"]},
}

FIELD_LABELS: dict = {
    "title"                  : "Title",
    "description"            : "Description",
    "service_name"           : "Service Name",
    "priority"               : "Priority",
    "request_type"           : "Request Type",
    "servicesubcategory_name": "Service Sub-Category",
    "org_name"               : "Organisation",
    "impact"                 : "Impact",
    "urgency"                : "Urgency",
    "name"                   : "Name",
    "symptom"                : "Symptom",
    "workaround"             : "Workaround",
    "root_cause"             : "Root Cause",
    "solution"               : "Solution",
    "error_code"             : "Error Code",
    "domain"                 : "Domain",
    "category"               : "Category",
    "outage"                 : "Outage",
    "slt_ids"                : "Linked SLT",
}

def _field_label(field: str) -> str:
    return FIELD_LABELS.get(field, field.replace("_", " ").title())

def _make_numbered_list_msg(field: str, options_with_labels: list) -> str:
    label = _field_label(field)
    lines = [f"Please select a {label}:\n"]
    for i, (display, _) in enumerate(options_with_labels, 1):
        lines.append(f"{i}. {display}")
    lines.append("\nType the number or the exact name.")
    return "\n".join(lines)

async def _resolve_numbered_option(ctx: ConnCtx, value: str, options_with_labels: list, field: str, session_id: str = "") -> Optional[str]:
    v = value.strip()
    if len(options_with_labels) == 1:
        display, api_val = options_with_labels[0]
        await send_reply(ctx, f"[OK] Auto-selected: {display}", session_id=session_id)
        return api_val

    if v.isdigit():
        idx = int(v) - 1
        if 0 <= idx < len(options_with_labels):
            display, api_val = options_with_labels[idx]
            await send_reply(ctx, f"[OK] Selected: {display}", session_id=session_id)
            return api_val
        await send_error(ctx, f"Invalid number. Please enter 1-{len(options_with_labels)}.", session_id=session_id)
        return None

    lower = v.lower()
    matches = [(d, a) for d, a in options_with_labels if d.lower().startswith(lower)]
    if len(matches) == 1:
        display, api_val = matches[0]
        await send_reply(ctx, f"[OK] Selected: {display}", session_id=session_id)
        return api_val
    if len(matches) > 1:
        await send_error(ctx, f"Ambiguous - did you mean: {', '.join(d for d, _ in matches)}? Please be more specific.", session_id=session_id)
        return None

    await send_error(ctx, f"Invalid value '{v}'. Please enter a number (1-{len(options_with_labels)}) or one of: {', '.join(d for d, _ in options_with_labels)}.", session_id=session_id)
    return None

# ---------------------------------------------
# DYNAMIC LIST HELPERS
# ---------------------------------------------

def _extract_names(items: list, *name_keys) -> list:
    names = []
    default_keys = name_keys or (
        "name","org_name","service_name","organization_name","title",
        "sla_name","slt_name","contract_name"
    )
    for item in items:
        if isinstance(item, str):
            names.append(item)
        elif isinstance(item, dict):
            # User requested to only display names, not IDs like (6d44c544-2c5a-4ebb-bd8f-ab661638a5ac)
            name = ""
            for k in default_keys:
                if item.get(k):
                    name = str(item[k])
                    break
            
            if name:
                names.append(name)
            else:
                # If no name is found, fall back to ID as last resort so the user can see something
                ref = (item.get("id") or item.get("uuid") or item.get("slt_id") or 
                       item.get("sla_id") or item.get("ticket_id") or "")
                if ref:
                    names.append(ref)
    return names

# ... (rest of helper functions)

async def send_list_as_reply(ctx: ConnCtx, field: str, options: list, session_id: str = ""):
    label = _field_label(field)
    lines = [f"Please select a {label} from the list below:\n"]
    for i, name in enumerate(options, 1):
        lines.append(f"{i}. {name}")
    lines.append("\nType the number or the exact name.")
    await send_reply(ctx, "\n".join(lines), session_id=session_id)

async def _read_live_list_selection(ctx: ConnCtx, options: list, required: bool = True, session_id: str = "") -> str:
    if len(options) == 1:
        await send_reply(ctx, f"[OK] Auto-selected: {options[0]}", session_id=session_id)
        return options[0]

    timeout = 300.0 if required else 60.0
    while True:
        try:
            msg = await asyncio.wait_for(ctx.input_queue.get(), timeout=timeout)
        except asyncio.TimeoutError:
            if required:
                raise
            return ""
        value = str(msg.get("value","")).strip()
        if not value:
            if required:
                await send_error(ctx, "This field is required.", session_id=session_id)
                continue
            return ""
        if value.isdigit():
            idx = int(value) - 1
            if 0 <= idx < len(options):
                resolved = options[idx]
                await send_reply(ctx, f"[OK] Selected: {resolved}", session_id=session_id)
                return resolved
            await send_error(ctx, f"Invalid number. Please enter 1-{len(options)}.", session_id=session_id)
            continue
        lower   = value.lower()
        matches = [o for o in options if o.lower().startswith(lower)]
        if len(matches) == 1:
            await send_reply(ctx, f"[OK] Selected: {matches[0]}", session_id=session_id)
            return matches[0]
        if len(matches) > 1:
            await send_error(ctx, f"Ambiguous - did you mean: {', '.join(matches)}? Please be more specific.", session_id=session_id)
            continue
        exact = [o for o in options if o.lower() == lower]
        if exact:
            await send_reply(ctx, f"[OK] Selected: {exact[0]}", session_id=session_id)
            return exact[0]
        await send_error(ctx, f"'{value}' not found. Please enter a number or exact name from the list.", session_id=session_id)

# ---------------------------------------------
# INTERACTIVE HELPERS
# ---------------------------------------------

async def send_status(ctx: ConnCtx, text: str, session_id: str = ""):
    await ctx.ws.send(json.dumps({"type": "status", "text": scrub_brands(text), "session_id": session_id}))

async def send_reply(ctx: ConnCtx, text: str, session_id: str = ""):
    await ctx.ws.send(json.dumps({"type": "reply", "text": scrub_brands(text), "session_id": session_id}))

async def send_error(ctx: ConnCtx, text: str, session_id: str = ""):
    await ctx.ws.send(json.dumps({"type": "error", "text": scrub_brands(text), "session_id": session_id}))

async def send_field_label_msg(ctx: ConnCtx, field: str, required: bool, session_id: str = ""):
    label = _field_label(field)
    bullet = "*" if required else "o"
    suffix = "" if required else "  (optional)"
    await send_reply(ctx, f"{bullet} {label}:{suffix}", session_id=session_id)

async def send_input_req(ctx: ConnCtx, field: str, required: bool = False, suppress_hint: bool = False, options: list = None, session_id: str = ""):
    payload = {
        "type": "input_req", 
        "field": field, 
        "required": required, 
        "session_id": session_id
    }
    if not suppress_hint:
        meta = FIELD_META.get(field, {})
        payload["hint"] = meta.get("hint", "")
        payload["label"] = _field_label(field)
        payload["allowed"] = meta.get("allowed", [])
    if options:
        payload["options"] = options
    
    await ctx.ws.send(json.dumps(payload))

def _find_id_by_name(items: list, chosen_name: str) -> Optional[str]:
    # Handle selection that might include the ID: "Name (UUID)"
    potential_id = ""
    if "(" in chosen_name and chosen_name.endswith(")"):
        potential_id = chosen_name.split("(")[-1].rstrip(")")

    name_keys = ("name","service_name","sla_name","slt_name","org_name","title","organization_name")
    id_keys = ("id", "uuid", "ticket_id", "service_id", "sla_id", "slt_id")
    
    for item in items:
        if not isinstance(item, dict):
            continue
        
        # Check if ID matches directly (if we extracted it)
        if potential_id:
            for ik in id_keys:
                if item.get(ik) == potential_id:
                    return potential_id

        # Check if any name field matches
        for nk in name_keys:
            val = item.get(nk)
            if val and str(val).strip().lower() == chosen_name.strip().lower():
                for ik in id_keys:
                    if item.get(ik):
                        return str(item[ik])
    return None

async def wait_for_input(ctx: ConnCtx, field: str, required: bool, session_id: str = "") -> str:
    meta = FIELD_META.get(field, {})
    timeout = 300.0 if required else 60.0

    raw_items = None
    options = None
    
    if field in ("org_name", "contract_org_name", "contract_provider_org"):
        raw_items = await itsm_client.get_organizations(ctx.token)
        options = _extract_names(raw_items)
    elif field in ("service_name", "linked_service_name"):
        raw_items = await itsm_client.get_services_list(ctx.token)
        options = _extract_names(raw_items)
    elif field == "slt_ids":
        raw_items = await itsm_client.get_slts(ctx.token)
        options = _extract_names(raw_items, "slt_name", "name", "title")

    numbered_opts: Optional[list] = None
    if field == "priority": numbered_opts = PRIORITY_OPTIONS
    elif field == "urgency": numbered_opts = URGENCY_OPTIONS
    elif field == "impact": numbered_opts = IMPACT_OPTIONS
    elif field == "category": numbered_opts = CATEGORY_OPTIONS
    elif field == "outage": numbered_opts = OUTAGE_OPTIONS
    elif field == "status": numbered_opts = SERVICE_STATUS_OPTIONS

    is_numbered = numbered_opts is not None
    is_live_list = bool(options)

    if is_live_list:
        if len(options) == 1:
            chosen = options[0]
            await send_field_label_msg(ctx, field, required, session_id=session_id)
            await send_reply(ctx, f"[OK] Auto-selected: {chosen}", session_id=session_id)
            resolved_id = _find_id_by_name(raw_items, chosen)
            return resolved_id if resolved_id else chosen
            
        await send_field_label_msg(ctx, field, required, session_id=session_id)
        await send_list_as_reply(ctx, field, options, session_id=session_id)
        await send_input_req(ctx, field, required, options=options, suppress_hint=True, session_id=session_id)
        chosen = await _read_live_list_selection(ctx, options, required=required, session_id=session_id)
        resolved_id = _find_id_by_name(raw_items, chosen)
        return resolved_id if resolved_id else chosen

    elif is_numbered:
        await send_field_label_msg(ctx, field, required, session_id=session_id)
        await send_reply(ctx, _make_numbered_list_msg(field, numbered_opts), session_id=session_id)
        await send_input_req(ctx, field, required, suppress_hint=True, session_id=session_id)
    else:
        await send_field_label_msg(ctx, field, required, session_id=session_id)
        await send_input_req(ctx, field, required, suppress_hint=False, session_id=session_id)

    while True:
        try:
            msg = await asyncio.wait_for(ctx.input_queue.get(), timeout=timeout)
        except asyncio.TimeoutError:
            if required:
                await send_error(ctx, f"Timed out waiting for required field '{field}'.", session_id=session_id)
                raise
            return ""

        value = str(msg.get("value", "")).strip()

        if is_numbered:
            if not value:
                if required:
                    await send_error(ctx, f"'{_field_label(field)}' is required.", session_id=session_id)
                    await send_input_req(ctx, field, required, suppress_hint=True, session_id=session_id)
                    continue
                return ""
            resolved = await _resolve_numbered_option(ctx, value, numbered_opts, field, session_id=session_id)
            if resolved is None:
                await send_input_req(ctx, field, required, suppress_hint=True, session_id=session_id)
                continue
            return resolved

        if field in ("start_date", "end_date", "contract_start_date", "contract_end_date"):
            if not value and not required:
                return ""
            normalized = normalize_date(value)
            if not normalized:
                await send_error(ctx, f"Cannot parse date '{value}'. Example: 2026-01-20T11:20", session_id=session_id)
                await send_input_req(ctx, field, required, suppress_hint=True, session_id=session_id)
                continue
            if normalized != value:
                await send_reply(ctx, f"[OK] Date auto-corrected: {value} -> {normalized}", session_id=session_id)
            return normalized

        meta = FIELD_META.get(field, {})
        allowed = meta.get("allowed", [])
        if allowed and value and value not in allowed:
            await send_error(ctx, f"Invalid value '{value}'. Allowed: {', '.join(allowed)}", session_id=session_id)
            await send_input_req(ctx, field, required, suppress_hint=True, session_id=session_id)
            continue

        if required and not value:
            await send_error(ctx, f"'{_field_label(field)}' is required.", session_id=session_id)
            await send_input_req(ctx, field, required, suppress_hint=True, session_id=session_id)
            continue

        return value

async def prompt_missing_params(ctx: ConnCtx, params: Dict[str, Any], schema: Dict[str, Any], session_id: str = "") -> Dict[str, Any]:
    required = schema.get("required", [])
    optional = schema.get("optional", [])
    
    for f in required:
        if not params.get(f):
            val = await wait_for_input(ctx, f, required=True, session_id=session_id)
            params[f] = val
            
    for f in optional:
        if not params.get(f):
            val = await wait_for_input(ctx, f, required=False, session_id=session_id)
            params[f] = val
            
    return params

# ---------------------------------------------
# MAIN DISPATCHER
# ---------------------------------------------

async def dispatch(ctx: ConnCtx, intent: str, entity: str, params: Dict[str, Any], filters: Dict[str, Any], session_id: str = ""):
    logger.info(f"Dispatching intent='{intent}' entity='{entity}'")
    token = ctx.token

    if intent == "get_stats":
        try:
            query = StatsQuery(entity=entity, **filters)
            resp = await itsm_client.get_stats(query.entity, query.model_dump(exclude={"entity"}), token)
            if resp and resp.status_code == 200:
                return 200, resp.json(), params
            
            detail = "Failed to fetch stats"
            if resp:
                try:
                    detail = resp.json().get("detail", resp.text)
                except:
                    detail = resp.text
            return resp.status_code if resp else 500, {"detail": detail}, params
        except Exception as e:
            return 500, {"detail": str(e)}, params

    if intent == "list_records":
        try:
            resp = await itsm_client.list_items(entity, token, filters)
            if resp and resp.status_code == 200:
                return 200, resp.json(), params
            
            detail = "Failed to list records"
            if resp:
                try:
                    # Try to get backend detail if available
                    detail = resp.json().get("detail", resp.text)
                except:
                    detail = resp.text
            return resp.status_code if resp else 500, {"detail": detail}, params
        except Exception as e:
            return 500, {"detail": str(e)}, params
    
    # ... (schema lookup)
    schema = INTENT_SCHEMAS.get(intent)
    if not schema:
        return 404, {"detail": f"Intent '{intent}' not supported yet in refactored version"}, params

    # Interactive parameter collection
    params = await prompt_missing_params(ctx, params, schema, session_id)
    
    # Custom interactive logic for SLA's slt_ids
    if intent == "create_sla" and not params.get("slt_ids"):
        # Fetch SLTs to show as options
        raw_slts = await itsm_client.get_slts(token)
        slt_names = _extract_names(raw_slts, "slt_name", "name", "title")
        
        if slt_names:
            await send_reply(ctx, "Would you like to link an SLT to this SLA?", session_id=session_id)
            await send_list_as_reply(ctx, "slt_ids", slt_names, session_id=session_id)
            await send_input_req(ctx, "slt_ids", required=False, options=slt_names, suppress_hint=True, session_id=session_id)
            
            # Use wait_for_input to get the selection
            slt_choice = await wait_for_input(ctx, "slt_ids", required=False, session_id=session_id)
            if slt_choice:
                # Find the ID for the chosen SLT name
                for slt in raw_slts:
                    if slt.get("slt_name") == slt_choice or slt.get("name") == slt_choice or slt.get("title") == slt_choice:
                        params["slt_ids"] = [slt.get("id", "")]
                        break
                else:
                    params["slt_ids"] = [slt_choice] # Fallback to using the text if ID not found

    # Validation using Pydantic
    try:
        if intent == "create_sla":
            # Ensure slt_ids is a list
            slt_ids = params.get("slt_ids", [])
            if isinstance(slt_ids, str):
                params["slt_ids"] = [slt_ids] if slt_ids.strip() else []
                
        model_instance = schema["model"](**params)
        validated_params = model_instance.model_dump()
    except Exception as e:
        logger.error(f"Validation error for {intent}: {e}")
        return 400, {"detail": f"Validation failed: {e}"}, params

    # Call API client
    method_name = intent # In this case, intent names match method names in ITSMClient
    method = getattr(itsm_client, method_name, None)
    
    if not method:
        return 501, {"detail": f"Method {method_name} not implemented in client"}, params

    try:
        resp = await method(validated_params, token)
        status = resp.status_code
        data = resp.json() if status < 400 else resp.text
        return status, data, params
    except Exception as e:
        logger.error(f"API call failed: {e}")
        return 500, {"detail": str(e)}, params

def build_final_reply(intent: str, status: int, data: Any, entity: str = "") -> str:
    ok = str(status).startswith("2")

    if intent == "get_stats":
        if ok:
            if isinstance(data, dict):
                reply = "Here are the requested statistics:\n"
                for k, v in data.items():
                    if isinstance(v, dict):
                        reply += f"\n**{k.replace('_', ' ').title()}**:\n"
                        for sub_k, sub_v in v.items():
                            reply += f"- {sub_k.replace('_', ' ').title()}: {sub_v}\n"
                    else:
                        reply += f"- {k.replace('_', ' ').title()}: {v}\n"
                return reply
            return str(data)
        else:
            detail = data.get("detail", data) if isinstance(data, dict) else data
            return f"[FAIL] Could not fetch statistics (HTTP {status}): {detail}"

    if intent == "list_records":
        if ok:
            # Flatten data if it's a dict containing lists (like contracts)
            items = []
            if isinstance(data, list):
                items = data
            elif isinstance(data, dict):
                # Flatten nested lists (e.g., {'provider_contracts': [...]})
                for k, v in data.items():
                    if isinstance(v, list):
                        items.extend(v)
            
            if not items:
                return f"No {entity} found."
            
            # Sort items by created_at DESC if available, or just reverse to show latest
            try:
                # If there's a created_at or id that looks like a date/serial, we can try sorting.
                # Reversing is often enough for recent items in many APIs.
                items.sort(key=lambda x: x.get("created_at") or x.get("id") or "", reverse=True)
            except:
                items.reverse()

            reply = f"Here are the {entity}:\n"
            for item in items:
                # Try common name/title keys
                title = (
                    item.get("title") or 
                    item.get("name") or 
                    item.get("sla_name") or 
                    item.get("slt_name") or 
                    item.get("contract_name") or
                    item.get("service_name") or
                    item.get("organization_name") or
                    "Unnamed Item"
                )
                reply += f"- {title}\n"
            
            return reply
        else:
            detail = data.get("detail", data) if isinstance(data, dict) else data
            return f"[FAIL] Could not list {entity} (HTTP {status}): {detail}"

    if ok:
        ref_id = ""
        if isinstance(data, dict):
            # Try to extract an ID or reference
            ref_id = (
                data.get("id") or 
                data.get("ref") or 
                data.get("uuid") or 
                data.get("ticket_id") or 
                data.get("change_ref") or
                ""
            )
        
        label = intent.replace('create_', '').replace('_', ' ').title()
        ref_part = f" (Reference: {ref_id})" if ref_id else ""
        return f"[OK] {label} successful{ref_part}."
    else:
        detail = data.get("detail", data) if isinstance(data, dict) else data
        return f"[FAIL] Operation failed (HTTP {status}): {detail}"
