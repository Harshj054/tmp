import httpx
import json
import re
import asyncio
from datetime import datetime
from typing import List, Dict, Any, AsyncGenerator, Optional
from app.core.config import settings
from app.core.logger import logger
from app.models.schemas import LLMResponse
from app.services.api_client import itsm_client

SYSTEM_PROMPT = """\
You are an expert ITSM Assistant. Your primary goal is to help users by using the available tools.

Available Modules for stats and listing:
- tickets (incidents/requests)
- problems (problem management)
- known_errors (known errors)
- changes (change management)
- services (IT services)
- slas (service level agreements)
- slts (service level targets)
- contracts (service contracts)

Common Statuses:
- assigned
- pending
- resolved
- closed
- all

Guidelines:
1. If the user is just saying hello, hi, or greeting you, respond naturally without calling any tools.
2. If the user asks who you are, explain you are an ITSM Assistant.
3. When a user asks for statistics, reports, or to create a record, call the appropriate function.
4. Don't explain what you are doing, just call the tool if needed.
5. If the user query is vague, ask for clarification.
6. For "how many", "count", "summary" queries, use 'get_stats'.
7. For "show", "list", "display" specific records (e.g., "show my tickets"), use 'list_records'.
8. For "create", "new", "raise" queries, use 'create_record'.
"""

GROQ_TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "get_stats",
            "description": "Get statistics for tickets, problems, changes, or services.",
            "parameters": {
                "type": "object",
                "properties": {
                    "entity": {
                        "type": "string",
                        "enum": ["tickets", "problems", "changes", "services"],
                        "description": "The module to get stats for."
                    },
                    "status": {
                        "type": "string",
                        "enum": ["assigned", "pending", "resolved", "approved", "rejected", "total", "all"],
                        "description": "Filter by status."
                    }
                },
                "required": ["entity"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "list_records",
            "description": "List records (tickets, problems, known_errors, changes, services, slas, slts, contracts) from the ITSM system.",
            "parameters": {
                "type": "object",
                "properties": {
                    "entity": {
                        "type": "string",
                        "enum": ["tickets", "problems", "known_errors", "changes", "services", "slas", "slts", "contracts"],
                        "description": "The module to list records from."
                    },
                    "status": {
                        "type": "string",
                        "description": "Optional filter by status."
                    }
                },
                "required": ["entity"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "create_record",
            "description": "Create a new record in the ITSM system.",
            "parameters": {
                "type": "object",
                "properties": {
                    "intent": {
                        "type": "string",
                        "enum": ["create_ticket", "create_problem", "create_known_error", "create_change", "create_service", "create_sla", "create_slt", "create_contract"],
                        "description": "The type of record to create."
                    },
                    "params": {
                        "type": "object",
                        "description": "Initial parameters extracted from user message."
                    }
                },
                "required": ["intent"]
            }
        }
    }
]

def _sanitize_history(history: List[Dict[str, str]]) -> List[Dict[str, str]]:
    sanitized = []
    if not history:
        return sanitized
    
    for h in history:
        role = h.get("role", "").lower()
        if role == "bot":
            role = "assistant"
        elif role not in ["user", "assistant", "system"]:
            role = "user"
            
        content = h.get("content") or h.get("text") or ""
        if content.strip():
            sanitized.append({"role": role, "content": content})
    
    return sanitized[-10:]

# Pre-classification patterns
_GREETING_PATTERNS = re.compile(
    r"^\s*(hi+|hello+|hey+|good\s+(morning|afternoon|evening|day)|greetings|howdy|sup|what'?s\s+up|how\s+are\s+you)\s*[!.?]*\s*$",
    re.IGNORECASE,
)
_IDENTITY_PATTERNS = re.compile(
    r"\b(who\s+are\s+you|what\s+are\s+you|introduce\s+yourself|your\s+name|tell\s+me\s+about\s+yourself)\b",
    re.IGNORECASE,
)

def _pre_classify(text: str) -> Optional[LLMResponse]:
    lower = text.lower().strip()
    if _GREETING_PATTERNS.match(lower):
        if "how are you" in lower:
            return LLMResponse(intent="fallback", params={"reply": "I'm doing great, thank you for asking! How can I assist you with your ITSM needs today?"})
        return LLMResponse(intent="fallback", params={"reply": "Hello! I am your ITSM Assistant. How can I help you today?"})
    if _IDENTITY_PATTERNS.search(lower):
        return LLMResponse(intent="fallback", params={"reply": "I am an ITSM Assistant designed to help you manage tickets, problems, changes, and other IT services."})
    return None

async def call_llm(user_message: str, history: List[Dict[str, str]] = None, token: str = "") -> LLMResponse:
    # Check pre-classification first
    pre = _pre_classify(user_message)
    if pre:
        return pre

    if settings.GROQ_API_KEY:
        return await call_groq_with_tools(user_message, history, token)
    else:
        return await call_ollama(user_message, history)

async def call_groq_with_tools(user_message: str, history: List[Dict[str, str]] = None, token: str = "") -> LLMResponse:
    try:
        from groq import AsyncGroq
    except ImportError:
        return await call_ollama(user_message, history)

    client = AsyncGroq(api_key=settings.GROQ_API_KEY)
    messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    messages.extend(_sanitize_history(history))
    
    if not messages or messages[-1].get("role") != "user":
        messages.append({"role": "user", "content": user_message})

    try:
        logger.info(f"Calling Groq Tools API (Model: llama-3.3-70b-versatile)")
        response = await client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=messages,
            tools=GROQ_TOOLS,
            tool_choice="auto",
            temperature=0.0
        )

        response_message = response.choices[0].message
        
        if hasattr(response_message, "tool_calls") and response_message.tool_calls:
            for tool_call in response_message.tool_calls:
                func_name = tool_call.function.name
                try:
                    args = json.loads(tool_call.function.arguments)
                except json.JSONDecodeError:
                    logger.warning(f"Model generated invalid JSON in tool arguments: {tool_call.function.arguments}")
                    continue
                
                if func_name == "get_stats":
                    entity = args.get("entity")
                    status = args.get("status", "all")
                    logger.info(f"Tool Call Success: get_stats({entity}, {status})")
                    return LLMResponse(intent="get_stats", entity=entity, filters={"status": status})
                
                if func_name == "list_records":
                    entity = args.get("entity")
                    status = args.get("status")
                    filters = {"status": status} if status else {}
                    logger.info(f"Tool Call Success: list_records({entity}, {status})")
                    return LLMResponse(intent="list_records", entity=entity, filters=filters)
                
                if func_name == "create_record":
                    intent = args.get("intent")
                    params = args.get("params", {})
                    logger.info(f"Tool Call Success: create_record({intent})")
                    return LLMResponse(intent=intent, params=params)

        content = response_message.content or ""
        if "<function=" in content:
            logger.info("Detected manual function tag generation, attempting manual parse.")
            match = re.search(r'<function=(\w+)(.*?)>', content)
            if match:
                fname, fargs_raw = match.groups()
                try:
                    fargs = json.loads(fargs_raw.strip())
                    if fname == "get_stats":
                        return LLMResponse(intent="get_stats", entity=fargs.get("entity"), filters={"status": fargs.get("status", "all")})
                    if fname == "create_record":
                        return LLMResponse(intent=fargs.get("intent"), params=fargs.get("params", {}))
                except:
                    pass

        return LLMResponse(intent="fallback", params={"reply": content})

    except Exception as e:
        logger.error(f"Groq tool call exception: {e}")
        return await call_ollama(user_message, history)

async def call_ollama(user_message: str, history: List[Dict[str, str]] = None) -> LLMResponse:
    url = f"{settings.OLLAMA_BASE_URL}/api/chat"
    messages = [{"role": "system", "content": "Return JSON only."}]
    messages.extend(_sanitize_history(history))
    if not messages or messages[-1]["role"] != "user":
        messages.append({"role": "user", "content": user_message})

    try:
        async with httpx.AsyncClient(timeout=60.0) as client:
            r = await client.post(url, json={
                "model": settings.OLLAMA_MODEL,
                "stream": False,
                "messages": messages
            })
            r.raise_for_status()
            content = r.json().get("message", {}).get("content", "")
            match = re.search(r"\{.*\}", content, re.DOTALL)
            if match:
                return LLMResponse(**json.loads(match.group()))
    except Exception as e:
        logger.error(f"Ollama fallback failed: {e}")
    return LLMResponse()

async def stream_llm_reply(user_message: str, history: List[Dict[str, str]] = None) -> AsyncGenerator[str, None]:
    if settings.GROQ_API_KEY:
        async for chunk in _stream_groq(user_message, history):
            yield chunk
    else:
        async for chunk in _stream_ollama(user_message, history):
            yield chunk

async def _stream_groq(user_message: str, history: List[Dict[str, str]] = None) -> AsyncGenerator[str, None]:
    try:
        from groq import AsyncGroq
        client = AsyncGroq(api_key=settings.GROQ_API_KEY)
        messages = _sanitize_history(history)
        if not messages or messages[-1]["role"] != "user":
            messages.append({"role": "user", "content": user_message})
            
        stream = await client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=messages,
            temperature=0.7,
            stream=True
        )
        async for chunk in stream:
            if chunk.choices[0].delta.content:
                yield chunk.choices[0].delta.content
    except Exception as e:
        yield f"Error: {e}"

async def _stream_ollama(user_message: str, history: List[Dict[str, str]] = None) -> AsyncGenerator[str, None]:
    url = f"{settings.OLLAMA_BASE_URL}/api/chat"
    messages = _sanitize_history(history)
    if not messages or messages[-1]["role"] != "user":
        messages.append({"role": "user", "content": user_message})
    
    try:
        async with httpx.AsyncClient(timeout=60.0) as client:
            async with client.stream("POST", url, json={
                "model": settings.OLLAMA_MODEL,
                "messages": messages,
                "stream": True
            }) as response:
                async for line in response.aiter_lines():
                    if line:
                        data = json.loads(line)
                        if "message" in data and "content" in data["message"]:
                            yield data["message"]["content"]
    except Exception as e:
        yield f"Error: {e}"

async def check_ollama_reachable():
    if settings.GROQ_API_KEY: return True
    try:
        async with httpx.AsyncClient(timeout=2.0) as client:
            r = await client.get(f"{settings.OLLAMA_BASE_URL}/api/tags")
            return r.status_code == 200
    except: return False
