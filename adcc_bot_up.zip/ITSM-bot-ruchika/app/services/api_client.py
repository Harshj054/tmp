import httpx
import json
from app.core.config import settings
from app.core.logger import logger

class ITSMClient:
    def __init__(self):
        self.base_url = settings.BACKEND_BASE.rstrip("/")
        self.admin_token = None

    async def login(self):
        url = f"{self.base_url}/api/auth/login"
        data = {
            "grant_type": "password",
            "username": settings.ITSM_USERNAME,
            "password": settings.ITSM_PASSWORD,
            "scope": "",
            "client_id": settings.ITSM_CLIENT_ID,
            "client_secret": settings.ITSM_CLIENT_SECRET
        }
        try:
            async with httpx.AsyncClient() as client:
                r = await client.post(url, data=data, headers={"accept": "application/json", "Content-Type": "application/x-www-form-urlencoded"})
                if r.status_code == 200:
                    self.admin_token = r.json().get("access_token")
                    logger.info("Successfully logged in as admin to ITSM Backend")
                    return True
                else:
                    logger.error(f"Login failed with status {r.status_code}: {r.text}")
        except Exception as e:
            logger.error(f"Login failed: {e}")
        return False

    def get_headers(self):
        # Strictly follow V2_ADCC.py: Always use the Admin token for backend actions.
        headers = {
            "accept": "application/json",
            "Content-Type": "application/json"
        }
        if self.admin_token:
            headers["Authorization"] = f"Bearer {self.admin_token}"
        return headers

    async def _post(self, endpoint, payload, token: str = None):
        if not self.admin_token:
            await self.login()
        url = f"{self.base_url}{endpoint}"
        async with httpx.AsyncClient(timeout=60.0, follow_redirects=True) as client:
            try:
                r = await client.post(url, json=payload, headers=self.get_headers())
                if r.status_code == 401:
                    logger.warning("Token expired (401), retrying login...")
                    if await self.login():
                        r = await client.post(url, json=payload, headers=self.get_headers())
                return r
            except httpx.HTTPError as e:
                logger.error(f"HTTP Error on POST {url}: {e}")
                raise

    async def _get(self, endpoint, token: str = None, params=None):
        if not self.admin_token:
            await self.login()
        url = f"{self.base_url}{endpoint}"
        async with httpx.AsyncClient(timeout=60.0, follow_redirects=True) as client:
            try:
                r = await client.get(url, params=params, headers=self.get_headers())
                if r.status_code == 401:
                    logger.warning("Token expired (401), retrying login...")
                    if await self.login():
                        r = await client.get(url, params=params, headers=self.get_headers())
                return r
            except httpx.HTTPError as e:
                logger.error(f"HTTP Error on GET {url}: {e}")
                raise

    async def create_ticket(self, params, token: str = None):
        return await self._post("/api/tickets", params, token)

    async def create_problem(self, params, token: str = None):
        return await self._post("/api/problems", params, token)

    async def create_change(self, params, token: str = None):
        return await self._post("/api/changes", params, token)

    async def create_known_error(self, params, token: str = None):
        return await self._post("/api/known-errors", params, token)

    async def get_stats(self, entity, filters, token: str = None):
        mapping = {
            "tickets": "/api/tickets/stats",
            "problems": "/api/problems/stats",
            "changes": "/api/changes/stats",
            "services": "/api/services/stats"
        }
        endpoint = mapping.get(entity)
        if not endpoint:
            return None
        return await self._get(endpoint, token, params=filters)

    async def list_items(self, entity, token: str = None, params=None):
        mapping = {
            "tickets": "/api/tickets",
            "problems": "/api/problems",
            "known_errors": "/api/known-errors",
            "changes": "/api/changes",
            "services": "/api/services/list",
            "slas": "/api/services/sla-details",
            "slts": "/api/services/slts",
            "contracts": "/api/services/contracts"
        }
        endpoint = mapping.get(entity)
        if not endpoint:
            return None
        return await self._get(endpoint, token, params=params)

    async def create_service(self, params, token: str = None):
        return await self._post("/api/services/", params, token)

    async def create_slt(self, params, token: str = None):
        return await self._post("/api/services/slts", params, token)

    async def create_sla(self, params, token: str = None):
        return await self._post("/api/services/slas", params, token)

    async def create_contract(self, params, token: str = None):
        return await self._post("/api/services/contracts", params, token)

    # --- WORKFLOW ACTIONS ---

    async def assign_item(self, entity: str, item_id: str, payload: dict, token: str = None):
        endpoint = f"/api/{entity}/{item_id}/assign"
        return await self._post(endpoint, payload, token)

    async def resolve_item(self, entity: str, item_id: str, payload: dict, token: str = None):
        endpoint = f"/api/{entity}/{item_id}/resolve"
        return await self._post(endpoint, payload, token)

    async def approve_change(self, change_id: str, payload: dict, token: str = None):
        endpoint = f"/api/changes/{change_id}/approve"
        return await self._post(endpoint, payload, token)

    # --- LOOKUP ACTIONS ---

    async def get_item_detail(self, entity: str, item_id: str, token: str = None):
        endpoint = f"/api/{entity}/{item_id}"
        return await self._get(endpoint, token)

    async def get_asset_detail(self, item_type: str, item_id: str, token: str = None):
        endpoint = f"/api/inventory/assets/{item_type}/{item_id}"
        return await self._get(endpoint, token)

    async def list_assets(self, token: str = None, params=None):
        return await self._get("/api/inventory/assets", token, params=params)

    async def get_inventory_stats(self, token: str = None):
        return await self._get("/api/inventory/stats", token)

    # --- DATA ADMIN & AGENTS ---

    def _unwrap_list(self, data):
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            # Backend often wraps lists in a key named after the entity or 'data/results'
            for key in ("organizations", "services", "slas", "slts", "tickets", "problems", 
                        "known_errors", "changes", "contracts", "data", "results", "items", "hierarchy"):
                if isinstance(data.get(key), list):
                    return data[key]
        return []

    async def get_organizations(self, token: str = None):
        # User suggested /api/organizations/hierarchy
        r = await self._get("/api/organizations/hierarchy", None)
        if r.status_code == 200:
            return self._unwrap_list(r.json())
        
        # Fallback to old endpoint if hierarchy fails
        r = await self._get("/api/data-admin/organizations", None)
        return self._unwrap_list(r.json()) if r.status_code == 200 else []

    async def get_services_list(self, token: str = None):
        r = await self._get("/api/services/list", None)
        return self._unwrap_list(r.json()) if r.status_code == 200 else []

    async def get_slas(self, token: str = None):
        r = await self._get("/api/services/sla-details", None)
        return self._unwrap_list(r.json()) if r.status_code == 200 else []

    async def get_slts(self, token: str = None):
        r = await self._get("/api/services/slts", None)
        return self._unwrap_list(r.json()) if r.status_code == 200 else []


itsm_client = ITSMClient()
