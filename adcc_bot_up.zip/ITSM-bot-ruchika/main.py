from fastapi import FastAPI
from groq import Groq
import os
import re

app = FastAPI()
client = Groq(api_key=os.environ.get("GROQ_API_KEY"))

@app.get("/chat")
def chat():
    response = client.chat.completions.create(
        model="qwen/qwen3-32b",
        messages=[
            {
                "role": "system",
                "content": "Do not include any <think> tags or reasoning. Only return the final answer."
            },
            {
                "role": "user",
                "content": "Hello"
            }
        ],
        temperature=0
    )

    output = response.choices[0].message.content

    # remove <think>...</think>
    clean_output = re.sub(r"<think>.*?</think>", "", output, flags=re.DOTALL).strip()

    return {"reply": clean_output}
