from groq import Groq
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

client = Groq(api_key=os.environ.get("GROQ_API_KEY"))

response = client.chat.completions.create(
    model="qwen/qwen3-32b",
    messages=[
        {
            "role": "system",
            "content": "Do not include any <think> or reasoning. Only return final answer."
        },
        {
            "role": "user",
            "content": "Write a FastAPI server example"
        }
    ],
    temperature=0
)

print(response.choices[0].message.content)
