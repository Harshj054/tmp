// content.js
// 1. Listen for messages from the Web Page
window.addEventListener("message", (event) => {
  // SECURITY: Only accept messages from the site hosting this script
  if (event.source !== window) return;

  if (event.data.type && event.data.type === "FROM_PAGE_TO_IPFS") {
    console.log("Extension received command:", event.data.command);

    // 2. Forward the message to the Extension Background Worker
    chrome.runtime.sendMessage(event.data, (response) => {
      // 3. Send the response BACK to the Web Page
      window.postMessage({
        type: "FROM_IPFS_TO_PAGE",
        payload: response
      }, "*");
    });
  }
});