// background.js
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.command === "UPLOAD_FILE") {
    uploadToIpfs(message.fileData, message.fileName).then(sendResponse);
    return true; // Keep the message channel open for async response
  }
});

async function uploadToIpfs(base64Data, fileName) {
  try {
    // Convert Base64 back to a Blob for upload
    const byteCharacters = atob(base64Data.split(',')[1]);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    const blob = new Blob([byteArray]);

    const formData = new FormData();
    formData.append("file", blob, fileName);

    // CALL THE LOCAL IPFS NODE
    const response = await fetch("http://127.0.0.1:5001/api/v0/add", {
      method: "POST",
      body: formData
    });

    if (!response.ok) {
        throw new Error(`IPFS Error: ${response.statusText}`);
    }

    const data = await response.json();
    return { success: true, cid: data.Hash };

  } catch (error) {
    return { success: false, error: error.message };
  }
}